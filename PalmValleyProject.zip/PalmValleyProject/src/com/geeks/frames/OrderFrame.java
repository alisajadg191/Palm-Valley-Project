/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.geeks.frames;

import com.geeks.beans.AccountBean;
import com.geeks.beans.OrderBean;
import com.geeks.beans.OrderDetailsBean;
import com.geeks.beans.ProductBean;
import com.geeks.beans.UserBean;
import com.geeks.dao.OrderDao;
import com.geeks.dao.OrderDetailsDao;
import com.geeks.dao.ProductDao;
import com.geeks.dao.UserDao;
import com.geeks.daoimpl.OrderDaoImpl;
import com.geeks.daoimpl.OrderDetailsDaoImpl;
import com.geeks.daoimpl.ProductDaoImpl;
import com.geeks.daoimpl.UserDaoImpl;
import com.geeks.util.BarcodeGenerator;
import com.geeks.util.UtilityClass;
import java.awt.MouseInfo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author khatr
 */
public class OrderFrame extends javax.swing.JFrame {

    private DefaultTableModel model;
    private Double grandTotal;
    private Double countTotal;
    private Double gst;
    private Double amountReceived;
    private Double change;
    private Double tax;
    private JPopupMenu popupMenu = null;
    private JMenuItem menuItem = null;
    private JMenuItem editItem = null;
    private UserBean userBean;
    private OrderBean orderBean;

    /**
     * Creates new form OrderFrame
     *
     * @param userBean
     * @throws java.sql.SQLException
     */
    public OrderFrame(UserBean userBean) throws SQLException {
        grandTotal = 0.0;
        countTotal = 0.0;
        gst = 0.0;
        change = 0.0;
        amountReceived = 0.0;
        this.userBean = userBean;
        initComponents();
        OrderDao orderDao = new OrderDaoImpl();
        String barcode = BarcodeGenerator.generateBarcode();
        Boolean isMatch = true;
        while (!isMatch) {
            isMatch = orderDao.checkBarcode(barcode);
            if (isMatch) {
                barcode = BarcodeGenerator.generateBarcode();
            }
        }
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        orderNoTxt.setText(barcode);
        orderNoTxt.setEnabled(false);
        populateProductTable();
        populateCustomerCombo();
        String tableHeader[] = {"Product Name", "Quantity", "Price", "Total"};
        model = new DefaultTableModel(tableHeader, 0);
        model.setRowCount(0);
        grandTotalTxt.setText(grandTotal.toString());
        countTotalTxt.setText(countTotal.toString());
        gstTxt.setText(gst.toString());
        //amountReceivedTxt.setText(amountReceived.toString());
        changeTxt.setText(change.toString());
        popupMenu = new JPopupMenu();
        popUpMenu(this);
        //updateBtn.setEnabled(false);
        //deleteBtn.setEnabled(false);
        updateBtn.setVisible(false);
        deleteBtn.setVisible(false);

    }

    public OrderFrame(UserBean userBean, OrderBean orderBean) throws SQLException, ParseException {
        grandTotal = 0.0;

        countTotal = 0.0;
        gst = 0.0;
        change = 0.0;
        amountReceived = 0.0;
        this.orderBean = orderBean;
        this.userBean = userBean;
        initComponents();
        populateOrderDetailsTable(orderBean.getOrderId());
        populateProductTable();
        populateCustomerCombo();
        orderNoTxt.setText(orderBean.getOrderNo());
        orderNoTxt.setEnabled(false);
        customerCombo.setSelectedItem(orderBean.getCustomer().getUsername());
        System.out.println(orderBean.getCustomer().getUsername());
        System.out.println(orderBean.getOrderDate().toString());
        dateTxt.setDate(orderBean.getOrderDate());
        updateBtn.setVisible(true);
        deleteBtn.setVisible(true);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        calculateTotals();
        saveBtn.setVisible(false);
        amountReceivedTxt.setText(Double.toString(0.0));
        amountPaidLbl.setText("Amount Paid : " + orderBean.getAmountPaid().toString());
        gst = Double.parseDouble(String.format("%.3f", Double.valueOf(grandTotalTxt.getText()) * 0.18));
        countTotal = Double.parseDouble(String.format("%.3f", Double.valueOf(grandTotalTxt.getText()) + Double.valueOf(grandTotalTxt.getText()) * 0.18));
        change = Double.parseDouble(String.format("%.3f", Double.valueOf(orderBean.getAmountPaid() - countTotal)));
        changeTxt.setText(change.toString());
        popupMenu = new JPopupMenu();
        popUpMenu(this);

    }

    public void popUpMenu(JFrame jframe) {
        menuItem = new JMenuItem("Remove Product");
        menuItem.getAccessibleContext().setAccessibleDescription("Remove Product");
        menuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Integer quantitySelected = (Integer) orderTable.getValueAt(orderTable.getSelectedRow(), 1);
                String name = (String) orderTable.getValueAt(orderTable.getSelectedRow(), 0);
                if (orderBean != null) {
                    Integer id = (Integer) orderTable.getModel().getValueAt(orderTable.getSelectedRow(), 0);
                    if (id != 0) {
                        OrderDetailsDao orderDetailsDao = new OrderDetailsDaoImpl();
                        OrderDetailsBean orderDetailsBean = orderDetailsDao.getOrderDetail((Integer) orderTable.getModel().getValueAt(orderTable.getSelectedRow(), 0));
                        orderDetailsBean.setModifiedBy(userBean.getUserId());
                        java.util.Date date = new java.util.Date(System.currentTimeMillis());
                        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                        String stringDate = sdf.format(date);
                        orderDetailsBean.setModifiedDate(Timestamp.valueOf(stringDate));
                        orderDetailsDao.delete(orderDetailsBean);
                        ProductDao productDao = new ProductDaoImpl();
                        ProductBean productBean = productDao.getProductByProductName(name);
                        productBean.setQuantity(productBean.getQuantity() + orderDetailsBean.getQuantity());
                        productDao.updateProduct(productBean);
                    }
                }

                model = (DefaultTableModel) orderTable.getModel();
                model.removeRow(orderTable.getSelectedRow());
                calculateTotals();
                for (int i = 0; i < productTable.getRowCount(); i++) {
                    if (productTable.getValueAt(i, 1).toString().equals(name)) {
                        int totalQuantity = (int) productTable.getValueAt(i, 5);
                        totalQuantity += quantitySelected;
                        productTable.setValueAt(totalQuantity, i, 5);
                        break;
                    }
                }
            }
        });
        popupMenu.add(menuItem);
        editItem = new JMenuItem("Edit");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        dateTxt = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        orderNoTxt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        customerCombo = new javax.swing.JComboBox<>();
        addCustomerBtn = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        productNameTxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        quantityTxt = new javax.swing.JTextField();
        addQuantityBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        productTable = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        orderTable = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        grandTotalTxt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        gstTxt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        countTotalTxt = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        amountReceivedTxt = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        changeTxt = new javax.swing.JTextField();
        saveBtn = new javax.swing.JButton();
        checkProductLbl = new javax.swing.JLabel();
        checkQuantityLbl = new javax.swing.JLabel();
        updateBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        backBtn = new javax.swing.JButton();
        checkAmountReceivedLbl = new javax.swing.JLabel();
        amountPaidLbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Date");

        jLabel2.setText("Order No");

        orderNoTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                orderNoTxtActionPerformed(evt);
            }
        });

        jLabel3.setText("Customer");

        customerCombo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                customerComboFocusGained(evt);
            }
        });

        addCustomerBtn.setText("Add");
        addCustomerBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCustomerBtnActionPerformed(evt);
            }
        });

        jLabel4.setText("Product");

        productNameTxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                productNameTxtFocusGained(evt);
            }
        });
        productNameTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productNameTxtActionPerformed(evt);
            }
        });
        productNameTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                productNameTxtKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                productNameTxtKeyReleased(evt);
            }
        });

        jLabel5.setText("Quantity");

        quantityTxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                quantityTxtFocusGained(evt);
            }
        });
        quantityTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                quantityTxtKeyReleased(evt);
            }
        });

        addQuantityBtn.setText("Add");
        addQuantityBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addQuantityBtnActionPerformed(evt);
            }
        });

        productTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        productTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                productTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(productTable);

        orderTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Name", "Quantity", "Price", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        orderTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                orderTableMouseReleased(evt);
            }
        });
        jScrollPane2.setViewportView(orderTable);

        jLabel6.setText("Grand Total");

        grandTotalTxt.setEnabled(false);
        grandTotalTxt.setFocusable(false);

        jLabel7.setText("GST (18%)");

        gstTxt.setEnabled(false);

        jLabel8.setText("Count Total");

        countTotalTxt.setEnabled(false);

        jLabel9.setText("Amount Received");

        amountReceivedTxt.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                amountReceivedTxtFocusGained(evt);
            }
        });
        amountReceivedTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                amountReceivedTxtActionPerformed(evt);
            }
        });
        amountReceivedTxt.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                amountReceivedTxtPropertyChange(evt);
            }
        });
        amountReceivedTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                amountReceivedTxtKeyPressed(evt);
            }
        });

        jLabel10.setText("Change");

        changeTxt.setEnabled(false);
        changeTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                changeTxtActionPerformed(evt);
            }
        });

        saveBtn.setText("Save");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });

        updateBtn.setText("Update");
        updateBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateBtnActionPerformed(evt);
            }
        });

        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });

        backBtn.setText("Back");
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 582, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(quantityTxt))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(productNameTxt))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(customerCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dateTxt, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                                    .addComponent(orderNoTxt))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(addCustomerBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(addQuantityBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(checkQuantityLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(checkProductLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(86, 86, 86)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 572, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(162, 162, 162)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(amountReceivedTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(checkAmountReceivedLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(grandTotalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(gstTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(countTotalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(changeTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(saveBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(updateBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(deleteBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(amountPaidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(amountPaidLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dateTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(orderNoTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(customerCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addCustomerBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(productNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(checkProductLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(quantityTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(addQuantityBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(checkQuantityLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(grandTotalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(gstTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(7, 7, 7)
                                        .addComponent(jLabel8))
                                    .addComponent(countTotalTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(amountReceivedTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(checkAmountReceivedLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jLabel10))
                            .addComponent(changeTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(saveBtn)
                            .addComponent(updateBtn)
                            .addComponent(deleteBtn)))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void orderNoTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_orderNoTxtActionPerformed

    }//GEN-LAST:event_orderNoTxtActionPerformed

    private void productTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_productTableMouseClicked
        String productName = (String) productTable.getValueAt(productTable.getSelectedRow(), 1);
        productNameTxt.setText(productName);
    }//GEN-LAST:event_productTableMouseClicked

    private void addQuantityBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addQuantityBtnActionPerformed

        Boolean isValid = validateFields();
        if (isValid) {
            model = (DefaultTableModel) orderTable.getModel();
            try {
                Boolean isMatch = false;
                String productName = productNameTxt.getText();
                Integer quantity = Integer.parseInt(quantityTxt.getText());
                BigDecimal bdPrice = (BigDecimal) productTable.getValueAt(productTable.getSelectedRow(), 3);
                Double price = bdPrice.doubleValue();
                Integer quantityAvailable = (Integer) productTable.getValueAt(productTable.getSelectedRow(), 5);
                int remainingQuantity = quantityAvailable - quantity;
                if (remainingQuantity < 0) {
                    checkQuantityLbl.setText("*Amount Not Available");
                } else {
                    for (int i = 0; i < orderTable.getRowCount(); i++) {
                        if (orderTable.getValueAt(i, 0).equals(productName)) {
                            isMatch = true;
                            Integer addQuantity = (Integer) orderTable.getValueAt(i, 1) + quantity;
                            orderTable.setValueAt(addQuantity, i, 1);
                            Double totalPrice = price * addQuantity;
                            orderTable.setValueAt(totalPrice, i, 3);
                            productTable.setValueAt(remainingQuantity, productTable.getSelectedRow(), 5);
                            break;
                        }
                    }
                    Double totalPrice = price * quantity;
                    if (!isMatch) {
                        productTable.setValueAt(remainingQuantity, productTable.getSelectedRow(), 5);
                        Vector<Object> data = new Vector<>();
                        if(orderBean != null) {
                            data.add(0);
                        }
                        
                        data.add(productName);
                        data.add(quantity);
                        data.add(price);
                        data.add(totalPrice);

                        model.addRow(data);
                        orderTable.setModel(model);
                    }

//                    grandTotal += totalPrice;
//                    gst += Double.parseDouble(String.format("%.3f", totalPrice * 0.18));
//                    countTotal += Double.parseDouble(String.format("%.3f", totalPrice + totalPrice * 0.18));
//
//                    grandTotalTxt.setText(grandTotal.toString());
//                    countTotalTxt.setText(countTotal.toString());
//                    gstTxt.setText(gst.toString());
                    calculateGrandTotal();
                    productNameTxt.setText("");
                    quantityTxt.setText("");

                }
            } catch (ArrayIndexOutOfBoundsException ex) {
                checkProductLbl.setText("*Product does not exist");
            }

        }


    }//GEN-LAST:event_addQuantityBtnActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed

        addData();
        clearFields();


    }//GEN-LAST:event_saveBtnActionPerformed

    private void addCustomerBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCustomerBtnActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CustomerFrame customerFrame = new CustomerFrame(userBean);
                customerFrame.setVisible(true);

            }
        });

    }//GEN-LAST:event_addCustomerBtnActionPerformed

    private void customerComboFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_customerComboFocusGained
        customerCombo.removeAllItems();
        populateCustomerCombo();
    }//GEN-LAST:event_customerComboFocusGained

    private void productNameTxtFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_productNameTxtFocusGained
        checkProductLbl.setText("");
    }//GEN-LAST:event_productNameTxtFocusGained

    private void quantityTxtFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_quantityTxtFocusGained
        checkQuantityLbl.setText("");
    }//GEN-LAST:event_quantityTxtFocusGained

    private void amountReceivedTxtPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_amountReceivedTxtPropertyChange
//        change = Double.valueOf(amountReceivedTxt.getText()) - countTotal;
//        changeTxt.setText(change.toString());
    }//GEN-LAST:event_amountReceivedTxtPropertyChange

    private void amountReceivedTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_amountReceivedTxtKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            try {
                if (orderBean != null) {
                    Double amountReceived = orderBean.getAmountPaid() + Double.valueOf(amountReceivedTxt.getText());
                    if (Double.valueOf(amountReceivedTxt.getText()) == orderBean.getAmountPaid()) {
                        change = amountReceived - Double.valueOf(countTotalTxt.getText());
                        changeTxt.setText(change.toString());
                    } else {

                        //change = Double.parseDouble(String.format("%.3f", Double.valueOf(amountReceivedTxt.getText()) - countTotal));
                        change = Double.parseDouble(String.format("%.3f", amountReceived - countTotal));
                        changeTxt.setText(change.toString());

                    }
                } else {
                    if (amountReceivedTxt.getText().trim().isEmpty()) {
                        change = Double.parseDouble(String.format("%.3f", 0.0 - countTotal));
                        changeTxt.setText(change.toString());
                    } else {
                        change = Double.parseDouble(String.format("%.3f", Double.valueOf(amountReceivedTxt.getText()) - countTotal));
                        System.out.println("this Code is running");
                        changeTxt.setText(change.toString());
                    }
                }
            } catch (NumberFormatException ex) {
                checkAmountReceivedLbl.setText("*Invalid Input");
            }

        }
    }//GEN-LAST:event_amountReceivedTxtKeyPressed

    private void quantityTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_quantityTxtKeyReleased
        try {
            Integer quantity = Integer.parseInt(quantityTxt.getText());
        } catch (NumberFormatException ex) {
            checkQuantityLbl.setText("*Invalid Input");
        }
        if (quantityTxt.getText().trim().isEmpty()) {
            checkQuantityLbl.setText("");
        }
    }//GEN-LAST:event_quantityTxtKeyReleased

    private void productNameTxtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_productNameTxtKeyPressed
        UtilityClass.searchFromTable(productTable, productNameTxt.getText());
    }//GEN-LAST:event_productNameTxtKeyPressed

    private void productNameTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_productNameTxtKeyReleased
        try {
            String productName = productNameTxt.getText();
        } catch (NumberFormatException ex) {
            checkProductLbl.setText("*Invalid Input");
        }
        if (productNameTxt.getText().trim().isEmpty()) {
            checkProductLbl.setText("");
        }
        if (productTable.getRowCount() != 0) {
            if (productTable.getRowCount() == 1) {
                productTable.setRowSelectionInterval(0, 0);
            }
        }
    }//GEN-LAST:event_productNameTxtKeyReleased

    private void orderTableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_orderTableMouseReleased
        if (evt.isPopupTrigger()) {
            int x = MouseInfo.getPointerInfo().getLocation().x;
            int y = MouseInfo.getPointerInfo().getLocation().y;
            popupMenu.show(this, x, y);
        }
    }//GEN-LAST:event_orderTableMouseReleased

    private void updateBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateBtnActionPerformed
        updateOrderDetails();
        updateOrder();
        ViewOrders viewOrders = new ViewOrders(userBean);
        viewOrders.setVisible(true);
        dispose();
    }//GEN-LAST:event_updateBtnActionPerformed

    private void productNameTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productNameTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_productNameTxtActionPerformed

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed
        if (orderBean != null) {
            ViewOrders viewOrders = new ViewOrders(userBean);
            viewOrders.setVisible(true);
            dispose();
        } else {
            RestaurantDashboard dashboard = new RestaurantDashboard(userBean);
            dashboard.setVisible(true);
            dispose();
        }
    }//GEN-LAST:event_backBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        OrderDao orderDao = new OrderDaoImpl();
        orderDao.deleteOrder(orderBean.getOrderId());
        ProductDao productDao = new ProductDaoImpl();
        ProductBean productBean = null;
        for (int i = 0; i < orderTable.getRowCount(); i++) {
            Integer quantity = (Integer) orderTable.getValueAt(i, 1);
            String productName = (String) orderTable.getValueAt(i, 0);
            productBean = productDao.getProductByProductName(productName);
            productBean.setQuantity(productBean.getQuantity() + quantity);
            productDao.updateProduct(productBean);

        }
        ViewOrders viewOrders = new ViewOrders(userBean);
        viewOrders.setVisible(true);
        dispose();
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void amountReceivedTxtFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_amountReceivedTxtFocusGained
//        amountReceivedTxt.setText("");
        checkAmountReceivedLbl.setText("");
    }//GEN-LAST:event_amountReceivedTxtFocusGained

    private void changeTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_changeTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_changeTxtActionPerformed

    private void amountReceivedTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_amountReceivedTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_amountReceivedTxtActionPerformed
    public void addData() {
        UserDao userDao = new UserDaoImpl();
        OrderDao orderDao = new OrderDaoImpl();
        ProductDao productDao = new ProductDaoImpl();
        OrderDetailsDao orderDetailsDao = new OrderDetailsDaoImpl();
        java.util.Date d = dateTxt.getDate();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String s = df.format(d);
        OrderBean orderBean = new OrderBean();
        orderBean.setOrderDate(Date.valueOf(s));
        orderBean.setOrderNo(orderNoTxt.getText());
        //Getting Details of customer by selected name
        UserBean userBean = userDao.getUserByName(customerCombo.getSelectedItem().toString());
        orderBean.setCustomer(userBean);
        orderBean.setOrderNo(orderNoTxt.getText());
        //Undecided
        AccountBean accountBean = new AccountBean();
        accountBean.setAccountId(5);
        orderBean.setAccount(accountBean);

        orderBean.setActive("1");
        orderBean.setCreatedBy(userBean.getUserId());
        orderBean.setModifiedBy(userBean.getUserId());
        java.util.Date date = new java.util.Date(System.currentTimeMillis());
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String stringDate = sdf.format(date);
        orderBean.setCreatedDate(Timestamp.valueOf(stringDate));
        orderBean.setModifiedDate(Timestamp.valueOf(stringDate));
        orderBean.setGrandTotal(Double.parseDouble(grandTotalTxt.getText()));
        orderBean.setAmountPaid(Double.parseDouble(amountReceivedTxt.getText()));
        if (Double.parseDouble(amountReceivedTxt.getText()) > Double.parseDouble(countTotalTxt.getText())) {
            orderBean.setStatus("paid");
        } else {
            orderBean.setStatus("unpaid");
        }
        //Adding data to order Table
        Integer row = orderDao.addOrder(orderBean);
        if (row > 0) {
            //Adding Data to order details Table
            OrderBean order = orderDao.getOrderByOrderNo(orderBean.getOrderNo());
            for (int i = 0; i < orderTable.getRowCount(); i++) {
                OrderDetailsBean orderDetailsBean = new OrderDetailsBean();
                orderDetailsBean.setOrder(order);
                String productName = (String) orderTable.getValueAt(i, 0);
                ProductBean productBean = productDao.getProductByProductName(productName);
                orderDetailsBean.setProductBean(productBean);
                Integer quantity = (Integer) orderTable.getValueAt(i, 1);
                Integer remainingQuantity = productBean.getQuantity() - quantity;
                productBean.setQuantity(remainingQuantity);
                productDao.updateProduct(productBean);
                orderDetailsBean.setQuantity(quantity);
                Double price = (Double) orderTable.getValueAt(i, 2);
                orderDetailsBean.setPrice(price);
                orderDetailsBean.setActive("1");
                orderDetailsBean.setCreatedBy(userBean.getUserId());
                orderDetailsBean.setModifiedBy(userBean.getUserId());
                orderDetailsBean.setCreatedDate(Timestamp.valueOf(stringDate));
                orderDetailsBean.setModifiedDate(Timestamp.valueOf(stringDate));
                orderDetailsDao.addOrderDetails(orderDetailsBean);
            }
        }

    }

    /**
     * @param rs
     * @return
     * @throws java.sql.SQLException
     */
    public static DefaultTableModel buildTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount() - 5;
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }
        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }
        return new DefaultTableModel(data, columnNames);
    }

    private void populateProductTable() throws SQLException {
        ProductDao productDao = new ProductDaoImpl();
        productTable.setModel(buildTableModel(productDao.getAllProducts()));
        productTable.removeColumn(productTable.getColumnModel().getColumn(0));

    }

    private void populateCustomerCombo() {
        UserDao userDao = new UserDaoImpl();
        List<UserBean> list = userDao.getCustomers();
        customerCombo.addItem("Walk Away Customer");
        for (UserBean user : list) {
            if (!user.getUsername().equals("Walk Away Customer")) {
                customerCombo.addItem(user.getUsername());
            }
        }
    }

    private Boolean validateFields() {
        Boolean isValid = true;
        if (productNameTxt.getText().trim().isEmpty()) {
            checkProductLbl.setText("*Select Product");
            isValid = false;
        }
        if (quantityTxt.getText().trim().isEmpty()) {
            checkQuantityLbl.setText("*Enter Quantity");
            isValid = false;
        } else if (Integer.valueOf(quantityTxt.getText()) < 1) {
            checkQuantityLbl.setText("*Invalid Amount");
            isValid = false;
        }

        return isValid;
    }

    //Update Orders
    public void updateOrderDetails() {
        for (int i = 0; i < orderTable.getRowCount(); i++) {
            ProductDao productDao = new ProductDaoImpl();
            Integer id = (Integer) orderTable.getModel().getValueAt(i, 0);
            OrderDetailsDao orderDetailsDao = new OrderDetailsDaoImpl();
            OrderDetailsBean orderDetailsBean = orderDetailsDao.getOrderDetail(id);
            if (orderDetailsBean != null && id != 0) {
                orderDetailsBean.setOrder(orderBean);
                String productName = (String) orderTable.getValueAt(i, 0);
                ProductBean productBean = productDao.getProductByProductName(productName);
                orderDetailsBean.setProductBean(productBean);
                Integer quantity = (Integer) orderTable.getValueAt(i, 1);

                if (orderDetailsBean.getQuantity() < quantity) {
                    orderDetailsBean.setQuantity(quantity - orderDetailsBean.getQuantity());
                    Integer remaining = quantity - orderDetailsBean.getQuantity();
                    System.out.println(quantity - orderDetailsBean.getQuantity());
                    Integer remaining1 = quantity - remaining;
                    System.out.println(remaining1);
                    Integer remainingQuantity = productBean.getQuantity() - remaining1;
                    System.out.println(remainingQuantity);
                    productBean.setQuantity(remainingQuantity);
                }
                productDao.updateProduct(productBean);
//                Integer remainingQuantity = productBean.getQuantity() - quantity;
//                productBean.setQuantity(remainingQuantity);
                orderDetailsBean.setQuantity(quantity);
                BigDecimal bdPrice = (BigDecimal) orderTable.getValueAt(i, 2);
                Double price = bdPrice.doubleValue();
                orderDetailsBean.setPrice(price);
                orderDetailsBean.setActive("1");
                orderDetailsBean.setCreatedBy(userBean.getUserId());
                orderDetailsBean.setModifiedBy(userBean.getUserId());
                java.util.Date date = new java.util.Date(System.currentTimeMillis());
                DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                String stringDate = sdf.format(date);
                orderDetailsBean.setCreatedDate(Timestamp.valueOf(stringDate));
                orderDetailsBean.setModifiedDate(Timestamp.valueOf(stringDate));
                //Update OrderDetailsDao is to be implemented
                orderDetailsDao.updateOrderDetails(orderDetailsBean);
            } else {

                orderDetailsBean.setOrder(orderBean);
                String productName = (String) orderTable.getValueAt(i, 0);
                ProductBean productBean = productDao.getProductByProductName(productName);
                orderDetailsBean.setProductBean(productBean);
                Integer quantity = (Integer) orderTable.getValueAt(i, 1);
                Integer remainingQuantity = productBean.getQuantity() - quantity;
                productBean.setQuantity(remainingQuantity);
                productDao.updateProduct(productBean);
                orderDetailsBean.setQuantity(quantity);
                Double price = (Double) orderTable.getValueAt(i, 2);
                orderDetailsBean.setPrice(price);
                orderDetailsBean.setActive("1");
                orderDetailsBean.setCreatedBy(userBean.getUserId());
                orderDetailsBean.setModifiedBy(userBean.getUserId());
                java.util.Date date = new java.util.Date(System.currentTimeMillis());
                DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
                String stringDate = sdf.format(date);
                orderDetailsBean.setCreatedDate(Timestamp.valueOf(stringDate));
                orderDetailsBean.setModifiedDate(Timestamp.valueOf(stringDate));
                orderDetailsDao.addOrderDetails(orderDetailsBean);
            }
        }
    }

    public void updateOrder() {
        UserBean customer = new UserBean();
        UserDao userDao = new UserDaoImpl();
        customer = userDao.getUserByName(customerCombo.getSelectedItem().toString());
        orderBean.setCustomer(customer);
        Double amountReceived = orderBean.getAmountPaid() + Double.parseDouble(amountReceivedTxt.getText());
        if (!amountReceivedTxt.getText().isEmpty() && amountReceived > Double.parseDouble(countTotalTxt.getText())) {
            orderBean.setAmountPaid(amountReceived);
            orderBean.setStatus("paid");
        } else if (!amountReceivedTxt.getText().isEmpty()) {
            orderBean.setAmountPaid(amountReceived);
            orderBean.setStatus("unpaid");
        } else {
            orderBean.setStatus("unpaid");
        }
        orderBean.setGrandTotal(Double.valueOf(grandTotalTxt.getText()));
        orderBean.setModifiedBy(userBean.getUserId());
        java.util.Date date = new java.util.Date(System.currentTimeMillis());
        DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String stringDate = sdf.format(date);
        orderBean.setModifiedDate(Timestamp.valueOf(stringDate));
        calculateGrandTotal();
        OrderDao orderDao = new OrderDaoImpl();
        orderDao.updateOrder(orderBean);

    }

    public void calculateGrandTotal() {
        grandTotal = 0.0;
        for (int i = 0; i < orderTable.getRowCount(); i++) {
            Object amount = orderTable.getValueAt(i, 3);
            System.out.println(amount.getClass());
            if (amount.getClass().toString().equals("class java.math.BigDecimal")) {
                BigDecimal bdPrice = (BigDecimal) amount;
                grandTotal += bdPrice.doubleValue();
            } else {
                grandTotal += (Double) amount;
            }
            System.out.println(grandTotal);
            //grandAmount += amount.doubleValue();
            //System.out.println(grandAmount);

        }
        gst = Double.parseDouble(String.format("%.3f", grandTotal * 0.18));
        countTotal = Double.parseDouble(String.format("%.3f", grandTotal + grandTotal * 0.18));
        gstTxt.setText(gst.toString());
        grandTotalTxt.setText(grandTotal.toString());
        countTotalTxt.setText(countTotal.toString());

    }

    private void clearFields() {
        java.util.Date date = new java.util.Date(System.currentTimeMillis());
        dateTxt.setDate(date);
        customerCombo.setSelectedIndex(0);
        productNameTxt.setText(null);
        quantityTxt.setText(null);
        checkProductLbl.setText("");
        checkQuantityLbl.setText("");
        grandTotalTxt.setText("");
        gstTxt.setText("");
        countTotalTxt.setText("");
        amountReceivedTxt.setText("");
        changeTxt.setText("");
        OrderDao orderDao = new OrderDaoImpl();
        String barcode = BarcodeGenerator.generateBarcode();
        Boolean isMatch = true;
        while (!isMatch) {
            isMatch = orderDao.checkBarcode(barcode);
            if (isMatch) {
                barcode = BarcodeGenerator.generateBarcode();
            }
        }
        orderNoTxt.setText(barcode);
        DefaultTableModel tableModel = (DefaultTableModel) orderTable.getModel();
        tableModel.setRowCount(0);
        productTable.clearSelection();
    }

    public void populateOrderDetailsTable(Integer orderId) throws SQLException {
        OrderDetailsDao orderDetailsDao = new OrderDetailsDaoImpl();
        ResultSet rst = orderDetailsDao.getOrderDetailsByOrderId(orderId);
        orderTable.setModel(buildOrderDetailsTableModel(rst));
        orderTable.removeColumn(orderTable.getColumnModel().getColumn(0));
    }

    public static DefaultTableModel buildOrderDetailsTableModel(ResultSet rs) throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        Vector<String> columnNames = new Vector<>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }
        Vector<Vector<Object>> data = new Vector<>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }
        return new DefaultTableModel(data, columnNames);
    }

    public void calculateTotals() {
        for (int i = 0; i < orderTable.getRowCount(); i++) {
            BigDecimal bdPrice = (BigDecimal) orderTable.getValueAt(i, 3);
            grandTotal += bdPrice.doubleValue();

        }
        grandTotalTxt.setText(Double.toString(grandTotal));
        gst = Double.parseDouble(String.format("%.3f", grandTotal * 0.18));
        gstTxt.setText(gst.toString());
        countTotal = Double.parseDouble(String.format("%.3f", grandTotal + grandTotal * 0.18));
        countTotalTxt.setText(countTotal.toString());
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addCustomerBtn;
    private javax.swing.JButton addQuantityBtn;
    private javax.swing.JLabel amountPaidLbl;
    private javax.swing.JTextField amountReceivedTxt;
    private javax.swing.JButton backBtn;
    private javax.swing.JTextField changeTxt;
    private javax.swing.JLabel checkAmountReceivedLbl;
    private javax.swing.JLabel checkProductLbl;
    private javax.swing.JLabel checkQuantityLbl;
    private javax.swing.JTextField countTotalTxt;
    private javax.swing.JComboBox<String> customerCombo;
    private com.toedter.calendar.JDateChooser dateTxt;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JTextField grandTotalTxt;
    private javax.swing.JTextField gstTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField orderNoTxt;
    private javax.swing.JTable orderTable;
    private javax.swing.JTextField productNameTxt;
    private javax.swing.JTable productTable;
    private javax.swing.JTextField quantityTxt;
    private javax.swing.JButton saveBtn;
    private javax.swing.JButton updateBtn;
    // End of variables declaration//GEN-END:variables
}
